This is the text-analyser of OSU file converted to txt file.

You can obtain converted txt files from OSU editor.


Open "OSU_Analyser.py" and input your target file.

The text files in 'bms' are sample converted text OSU files.

When you input your target file, do not include ' 

and please remove all the non-english letters in filename and file content.

Hope this will help you while making other beatmaps. Thank you


waterloocanucks1@gmail.com
Jai Yeon Choi